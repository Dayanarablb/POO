
package p2taller1bautistadayanara;
/**
 *
 * @author DAYANARA BAUTISTA
 */
public class ProductoComestible extends Producto {
    
    private String Sabor;

    public ProductoComestible(String Sabor, String nombreProducto, int Codigo, double Precio, int stock, String fechaCaducidad) {
        super(nombreProducto, Codigo, Precio, stock, fechaCaducidad);
        this.Sabor = Sabor;
    }
    public String getSabor() {
        return Sabor;
    }

    public void setSabor(String Sabor) {
        this.Sabor = Sabor;
    }
}
   

