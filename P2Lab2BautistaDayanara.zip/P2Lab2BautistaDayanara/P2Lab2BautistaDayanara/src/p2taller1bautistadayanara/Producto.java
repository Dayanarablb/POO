package p2taller1bautistadayanara;
import Formularios.RegistroProducto;

/**
 *
 * @author DAYANARA BAUTISTA 
 */
public class Producto { //Clase Padre
    //Atributos
    private String nombreProducto;
    private int Codigo;
    private double Precio;
    private int stock;
    private String fechaCaducidad;
    //Constructor
    public Producto(String nombreProducto, int Codigo, double Precio, int stock, String fechaCaducidad) {
        this.nombreProducto = nombreProducto;
        this.Codigo = Codigo;
        this.Precio = Precio;
        this.stock = stock;
        this.fechaCaducidad = fechaCaducidad;
    }
    public Producto(){
        
    }
    public String getNombreProducto() {
        return nombreProducto;
    }
    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
    public int getCodigo() {
        return Codigo;
    }
    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }
    public double getPrecio() {
        return Precio;
    }
    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }
    public int getStock() {
        return stock;
    }
    public void setStock(int stock) {
        this.stock = stock;
    }
     public String getFechaCaducidad() {
        return fechaCaducidad;
    }
    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }   
}
