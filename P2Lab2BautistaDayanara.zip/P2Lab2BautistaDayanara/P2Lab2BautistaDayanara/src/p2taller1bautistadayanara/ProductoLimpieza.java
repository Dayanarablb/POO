package p2taller1bautistadayanara;
/**
 *
 * @author DAYANARA BAUTISTA
 */
public class ProductoLimpieza extends Producto {
    
    private String usoParticular;

    public ProductoLimpieza(String usoParticular, String nombreProducto, int Codigo, double Precio, int stock, String fechaCaducidad) {
        super(nombreProducto, Codigo, Precio, stock, fechaCaducidad);
        this.usoParticular = usoParticular;
    }
    public String getUsoParticular() {
        return usoParticular;
    }
    public void setUsoParticular(String usoParticular) {
        this.usoParticular = usoParticular;
    }     
}
