
package p2taller1bautistadayanara;
import Formularios.Menu;
/**
 *
 * @author DAYANARA BAUTISTA
 */
public class P2Taller1BautistaDayanara {

    public static void main(String[] args) {
        
        Menu menu = new Menu ();
        menu.setVisible(true);
        
    }   
}
